"""Current version of package deflate_dict"""
__version__ = "1.0.5"