from .deflate import deflate
from .inflate import inflate

__all__ = ["deflate", "inflate"]